import 'package:flutter/material.dart';

import '../../../../domain/entities/profile.dart';

final class ProfileAvatar extends StatelessWidget {
  const ProfileAvatar({
    super.key,
    required this.profile,
  });

  final Profile profile;

  @override
  Widget build(BuildContext context) {
    final avatarUrl = profile.avatarUrl;

    return CircleAvatar(
      radius: 42,
      backgroundImage: avatarUrl != null && avatarUrl.isNotEmpty
          ? NetworkImage(avatarUrl)
          : null,
      child: avatarUrl == null || avatarUrl.isEmpty
          ? const Icon(
              Icons.person,
              size: 42,
            )
          : null,
    );
  }
}