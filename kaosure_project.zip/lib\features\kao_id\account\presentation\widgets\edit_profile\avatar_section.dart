import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../../../core/providers/core_providers.dart';
import '../../providers/profile_controller_provider.dart';

final class AvatarSection extends ConsumerWidget {
  const AvatarSection({
    super.key,
    required this.avatarUrl,
  });

  final String? avatarUrl;

  @override
  Widget build(
    BuildContext context,
    WidgetRef ref,
  ) {
    final state = ref.watch(
      profileControllerProvider,
    );

    return Center(
      child: SizedBox(
        width: 120,
        height: 120,
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Align(
              alignment: Alignment.center,
              child: CircleAvatar(
                radius: 48,
                backgroundImage: avatarUrl != null
                    ? NetworkImage(avatarUrl!)
                    : null,
                child: avatarUrl == null
                    ? const Icon(
                        Icons.person,
                        size: 48,
                      )
                    : null,
              ),
            ),
            Positioned(
              right: 8,
              bottom: 8,
              child: Material(
                color: Theme.of(context)
                    .colorScheme
                    .primary,
                shape: const CircleBorder(),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: () async {
                    debugPrint('Camera tapped');

                    final picker = ref.read(
                      imagePickerServiceProvider,
                    );

                    final Uint8List? image =
                        await picker.pickImage();

                    if (image == null) {
                      debugPrint(
                        'No image selected',
                      );
                      return;
                    }

                    debugPrint(
                      'Image selected: ${image.length} bytes',
                    );

                    try {
                      await ref
                          .read(
                            profileControllerProvider
                                .notifier,
                          )
                          .changeAvatar(
                            imageBytes: image,
                          );

                      debugPrint(
                        'Avatar upload completed',
                      );
                    } catch (e, s) {
                      debugPrint(
                        'Avatar upload error: $e',
                      );
                      debugPrint(
                        s.toString(),
                      );
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: state.isLoading
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child:
                                CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(
                            Icons.camera_alt,
                            color: Colors.white,
                            size: 18,
                          ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}